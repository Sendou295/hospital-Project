@extends('layouts.admin')
@section('admin_content')

<h3>Welcome to Greenwich Hospital's Dashboard</h3>

@endsection