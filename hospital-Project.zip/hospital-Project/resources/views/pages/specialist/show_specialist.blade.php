@extends('layouts.user')
@section('content')

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Information</title>


    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous" />
    <link rel="stylesheet" href="{{asset('frontend/./css/doctor-info.css')}}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans:wght@400;700&display=swap" rel="stylesheet">
    <!-- Link CSS -->
    <link rel="stylesheet" href="{{asset('frontend/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/css/responsive.css')}}">
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Link JS -->
    <script src="{{asset('frontend/js/script.js')}}"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        clifford: '#da373d',
                    }
                }
            }
        }
    </script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>
    <!-- Doctor Detail -->
    <div class="doctor-container">
        <div class="container">
            <div class="heading-section">
                <h2>Specialist Detail</h2>
            </div>
            @foreach ($details_specialists as $key => $specialist_value)
            {{csrf_field()}}
            <div class="row">
                
                <div class="col-md-3"> 
                    <img src="{{URL::to('../upload/specialist/'.$specialist_value->specialist_image)}}" class="img-fluid" alt="">
                </div>
                <div class="col-md-9">
                    <div class="doctor-dtl">
                        <div class="doctor-info">
                            <div class="doctor-name"></div>
                        </div>
                        <div class="row">
                            <div class="dtl-container">
                                <div class="col-md-12 dtl-desc">
                                    <h1 class="lead">Specialist Name: {{$specialist_value->specialist_name}}</h1>
                                    <h2>Position: {{$specialist_value->position_name}}</h2>
                                    <h2>Email: {{$specialist_value->specialist_email}}</h2>
                                </div>
                                <div class="col-md-12">
                                    <button class="dropdown-button" type="button" data-toggle="collapse" data-target="#intro" aria-expanded="false" aria-controls="collapseExample">
                                        <span class="dropdown-title text-truncate">Introduction</span>
                                        <span class="dropdown-arrow">
                                            ❕
                                        </span>
                                    </button>
                                    <div class="collapse" id="intro">
                                        <div class="card card-body" id="doctor-introduction">
                                            {{$specialist_value->specialist_introduction}}
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button class="dropdown-button" type="button" data-toggle="collapse" data-target="#achievements" aria-expanded="false" aria-controls="collapseExample">
                                        <span class="dropdown-title text-truncate">Members Of The Organizing Committee 	</span>
                                        <span class="dropdown-arrow">
                                            🎖
                                        </span>
                                    </button>
                                    <div class="collapse" id="achievements">
                                        <div class="card card-body" id="doctor-achievements">
                                            {{$specialist_value->specialist_members_of_the_organizing_committee	}}
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button class="dropdown-button" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                        <span class="dropdown-title text-truncate">Department  </span>
                                        <span class="dropdown-arrow">
                                            👨‍⚕️
                                        </span>
                                    </button>
                                    <div class="collapse" id="collapseExample">
                                        <div class="card card-body" id="doctor-introduction">
                                            {{$specialist_value->department_name}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="doctor-info-tabs">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="description-tab" data-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true">Description</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="review-tab" data-toggle="tab" href="#review" role="tab" aria-controls="review" aria-selected="false">Rate</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
                        Areas Of Expertise: <br>{{$specialist_value->specialist_areas_of_expertise}} <br>
                        Award Title: <br>{{$specialist_value->specialist_award_title}}<br>
                        Research Works: <br>{{$specialist_value->specialist_research_works}}
                    </div>
                    
                    <div class="tab-pane fade" id="review" role="tabpanel" aria-labelledby="review-tab">
                        <div class="review-heading">REVIEWS</div>
                        <p class="mb-20">There are no reviews yet.</p>
                        <form class="review-form">
                            <div class="form-group">
                                <label>Your rating</label>
                                <div class="reviews-counter">
                                    <div class="rate">
                                        <input type="radio" id="star5" name="rate" value="5" />
                                        <label for="star5" title="text">5 stars</label>
                                        <input type="radio" id="star4" name="rate" value="4" />
                                        <label for="star4" title="text">4 stars</label>
                                        <input type="radio" id="star3" name="rate" value="3" />
                                        <label for="star3" title="text">3 stars</label>
                                        <input type="radio" id="star2" name="rate" value="2" />
                                        <label for="star2" title="text">2 stars</label>
                                        <input type="radio" id="star1" name="rate" value="1" />
                                        <label for="star1" title="text">1 star</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Your message</label>
                                <textarea class="form-control" rows="10"></textarea>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="" class="form-control" placeholder="Name*">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="" class="form-control" placeholder="Email Id*">
                                    </div>
                                </div>
                            </div>
                            <button class="round-black-btn">Submit Review</button>
                        </form>
                    </div>
                </div>
            </div>
            <div style="text-align:center;font-size:14px;padding-bottom:20px;">Get free icon packs for your next project at <a href="http://iiicons.in/" target="_blank" style="color:#ff5e63;font-weight:bold;">www.iiicons.in</a></div>
        @endforeach
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="	sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>

    
</body>
@endsection