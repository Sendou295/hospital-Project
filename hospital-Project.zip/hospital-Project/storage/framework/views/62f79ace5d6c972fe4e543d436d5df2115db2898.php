
<?php $__env->startSection('admin_content'); ?>


<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Update Special Service
            </header>
            <?php
            $message = Session::get('message');
            if($message){
                echo '<span class = "text-alert">',$message.'</span>';
                Session::put('message',null);
            }
            ?>
            <div class="panel-body">
                <?php $__currentLoopData = $edit_special_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/update-special_service/'.$edit_value->special_service_id)); ?>" 
                        method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="exampleInputEmail1">Special Service Name</label>
                        <input type="text" value="<?php echo e($edit_value->special_service_name); ?>" name="special_service_name" 
                        class="form-control" id="exampleInputEmail1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Description</label>
                        <textarea style="resize:none" rows="5" type="text" name="special_service_desc" class="form-control" 
                        id="exampleInputPassword1" ><?php echo e($edit_value->special_service_desc); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Department</label>
                        <select name="special_service_department" class="form-control input-sm m-bot15">
                            <?php $__currentLoopData = $special_service_department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $department_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($department_value->department_id==$edit_value->department_id): ?>
                            <option selected value="<?php echo e($department_value->department_id); ?>"><?php echo e($department_value->department_name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($department_value->department_id); ?>"><?php echo e($department_value->department_name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Image</label>
                        <input type="file" name="special_service_image" class="form-control" id="exampleInputEmail1">
                        <img src="<?php echo e(URL::to('upload/special_service/'.$edit_value->special_service_image)); ?>" height="100" width="100">
                    </div>
                    <button type="submit" name="update_special_service" class="btn btn-info">Update Special Service</button>
                </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\hospital-Project\resources\views/admin/special_service/edit_special_service.blade.php ENDPATH**/ ?>