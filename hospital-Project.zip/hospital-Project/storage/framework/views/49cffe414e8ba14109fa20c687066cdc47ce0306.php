
<?php $__env->startSection('admin_content'); ?>


<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Update Equipment
            </header>
            <?php
            $message = Session::get('message');
            if($message){
                echo '<span class = "text-alert">',$message.'</span>';
                Session::put('message',null);
            }
            ?>
            <div class="panel-body">
                <?php $__currentLoopData = $edit_equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/update-equipment/'.$edit_value->equipment_id)); ?>" 
                        method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="exampleInputEmail1">Equipment Name</label>
                        <input type="text" value="<?php echo e($edit_value->equipment_name); ?>" name="equipment_name" 
                        class="form-control" id="exampleInputEmail1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Description</label>
                        <textarea style="resize:none" rows="5" type="text" name="equipment_desc" class="form-control" 
                        id="exampleInputPassword1" ><?php echo e($edit_value->equipment_desc); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Equipment Image</label>
                        <input type="file" name="equipment_image" class="form-control" id="exampleInputEmail1">
                        <img src="<?php echo e(URL::to('../upload/equipment/'.$edit_value->equipment_image)); ?>" height="100" width="100">
                        
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Service</label>
                        <select name="equipment_service" class="form-control input-sm m-bot15">
                            <?php $__currentLoopData = $equipment_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($service_value->service_id==$edit_value->service_id): ?>
                            <option selected value="<?php echo e($service_value->service_id); ?>"><?php echo e($service_value->service_name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($service_value->service_id); ?>"><?php echo e($service_value->service_name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit" name="update_equipment" class="btn btn-info">Update Equipment</button>
                </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\hospital-Project\resources\views/admin/equipment/edit_equipment.blade.php ENDPATH**/ ?>