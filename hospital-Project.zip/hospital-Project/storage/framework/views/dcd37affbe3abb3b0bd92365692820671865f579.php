
<?php $__env->startSection('admin_content'); ?>

<h3>Welcome to Greenwich Hospital's Dashboard</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\hospital-Project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>