
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Information</title>


    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css"
        integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/./css/speciality.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kumbh+Sans:wght@400;700&display=swap" rel="stylesheet">
    <!-- Link CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/responsive.css')); ?>">
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Link JS -->
    <script src="<?php echo e(asset('frontend/js/script.js')); ?>"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        clifford: '#da373d',
                    }
                }
            }
        }
    </script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>

<body>

    <!-- Specialities -->
    <div class="speciality-container">
        <div class="speciality-header">
            <?php $__currentLoopData = $base; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$base_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e(csrf_field()); ?>

            <div class="speciality-img">
                <img src="<?php echo e(URL::to('../upload/base/'.$base_value->base_image)); ?>" alt="speciality-image">
            </div>
            <h1 class="specility-name"><?php echo e($base_value->base_name); ?></h1>
            <h2 class="spciality-hotline">📞 Phone Number: <a href="#"><?php echo e($base_value->base_phone); ?></a></h2>
            <h2 class="spciality-hotline">🏡 Address: <a href="#"><?php echo e($base_value->base_address); ?></a></h2>
            <h2 class="spciality-hotline">Under: <a href="#">Greenwich International General Hospital</a></h2>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="speciality-content">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item active">
                    <a class="nav-link" id="description-tab" data-toggle="tab" href="#description" role="tab"
                        aria-controls="description" aria-selected="true">Introduction</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="team-tab" data-toggle="tab" href="#team" role="tab" aria-controls="team"
                        aria-selected="false">Đội Ngũ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="equipment-tab" data-toggle="tab" href="#equipment" role="tab"
                        aria-controls="equipment" aria-selected="false">Cơ Sở Vật Chất Và Trang Thiết Bị</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="review-tab" data-toggle="tab" href="#review" role="tab"
                        aria-controls="review" aria-selected="false">Đánh giá</a>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show" id="description" role="tabpanel" aria-labelledby="description-tab">
                    Là chuyên khoa mũi nhọn hàng đầu tại bệnh viện Quốc tế Vinmec, khoa Sản phụ khoa quy tụ đội ngũ bác
                    sĩ, điều dưỡng đến từ các bệnh viện phụ sản lớn tại thành phố Hồ Chí Minh, không chỉ có kinh nghiệm
                    chuyên môn cao mà còn có sự hiểu biết và quan tâm sát sao đến tâm lý, trạng thái của từng sản phụ.
                    Khoa Sản phụ khoa tại Bệnh viện Đa khoa Quốc tế Vinmec Central Park được đầu tư hệ thống phòng sinh
                    hiện đại, mang đến cảm giác thoải mái thư giãn, giảm tối đa sự đau đớn cho sản phụ trong suốt quá
                    trình vượt cạn.
                </div>
                <div class="tab-pane fade show" id="team" role="tabpanel" aria-labelledby="team-tab">
                    <!--Specialist Section -->
                    <div class="team-section">
                        <section id="team" class="team team-bg py-5">
                            <div class="container">
                                <div class="section-title">
                                    <p class="main-team-heading">Doctors in Specialty</p>
                                    <p class="main-team-subheading">Team of Experts</p>
                                </div>
                                <div class="row">
                                    <?php $__currentLoopData = $specialist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$specialist_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e(csrf_field()); ?>

                                    <div class="col-lg-6">
                                        <div class="member d-flex align-items-start">
                                            <div class="pic"><img
                                                    src="<?php echo e(URL::to('../upload/specialist/'.$specialist_value->specialist_image)); ?>"
                                                    class="img-fluid" alt=""></div>
                                            <div class="member-info">
                                                <p class="member-heading">
                                                    Position:<?php echo e($specialist_value->specialist_academic_rank); ?>

                                                </p>
                                                <p class="member-heading">
                                                    Full Name:<?php echo e($specialist_value->specialist_name); ?>

                                                </p>
                                                
                                                <span><?php echo e($specialist_value->specialist_degree); ?></span>
                                                <p class="member-para"><?php echo e($specialist_value->specialist_introduction); ?>

                                                </p>
                                                <div class="social">
                                                    <a
                                                        href="<?php echo e(URL::to('/detailspecialist/'.$specialist_value->specialist_id)); ?>"><i
                                                            class="fab fa-twitter team-icon"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="wrapper">
                        <ul id="pagination">
                            <li><a href="#">«</a></li>
                            <li><a href="#">1</a></li>
                            <li><a href="#">»</a></li>
                        </ul>
                    </div>
                </div>
                <div class="tab-pane fade show" id="equipment" role="tabpanel" aria-labelledby="equipment-tab">
                    <!--Equipment Section -->
                    <div class="team-section">
                        <section id="team" class="team team-bg py-5">
                            <div class="container">
                                <div class="section-title">
                                    <p class="main-team-heading">Doctors in Specialty</p>
                                    <p class="main-team-subheading">Team of Experts</p>
                                </div>
                                <div class="row">
                                    <?php $__currentLoopData = $equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$equipment_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e(csrf_field()); ?>

                                    <div class="col-lg-6">
                                        <div class="member d-flex align-items-start">
                                            <div class="pic"><img
                                                    src="<?php echo e(URL::to('../upload/equipment/'.$equipment_value->equipment_image)); ?>"
                                                    class="img-fluid" alt=""></div>
                                            <div class="member-info">
                                                <p class="member-heading">
                                                    <?php echo e($equipment_value->equipment_name); ?>

                                                </p>
                                                <p class="member-para"><?php echo e($equipment_value->equipment_desc); ?>

                                                </p>
                                                <p class="member-para"><?php echo e($equipment_value->service_id); ?>

                                                </p>
                                                <div class="social">
                                                    <a
                                                        href="<?php echo e(URL::to('/detailspecialist/'.$equipment_value->equipment_id)); ?>"><i
                                                            class="fab fa-twitter team-icon"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="wrapper">
                        <ul id="pagination">
                            <li><a href="#">«</a></li>
                            <li><a href="#">1</a></li>
                            <li><a href="#">»</a></li>
                        </ul>
                    </div>
                </div>
            
                <div class="tab-pane fade" id="review" role="tabpanel" aria-labelledby="review-tab">
                    <div class="review-heading">REVIEWS</div>
                    <p class="mb-20">There are no reviews yet.</p>
                    <form class="review-form">
                        <div class="form-group">
                            <label>Your rating</label>
                            <div class="reviews-counter">
                                <div class="rate">
                                    <input type="radio" id="star5" name="rate" value="5" />
                                    <label for="star5" title="text">5 stars</label>
                                    <input type="radio" id="star4" name="rate" value="4" />
                                    <label for="star4" title="text">4 stars</label>
                                    <input type="radio" id="star3" name="rate" value="3" />
                                    <label for="star3" title="text">3 stars</label>
                                    <input type="radio" id="star2" name="rate" value="2" />
                                    <label for="star2" title="text">2 stars</label>
                                    <input type="radio" id="star1" name="rate" value="1" />
                                    <label for="star1" title="text">1 star</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Your message</label>
                            <textarea class="form-control" rows="10"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="" class="form-control" placeholder="Name*">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="" class="form-control" placeholder="Email Id*">
                                </div>
                            </div>
                        </div>
                        <button class="round-black-btn">Submit Review</button>
                    </form>
                </div>

                <!-- Pagination -->
            </div>
        </div>
    </div>

    <!-- Side Banner -->
    <a href="https://youtu.be/7IoMG_NN7lA" target="_blank" class="link">Watch Hospital on youtube <i
            class="fab fa-youtube"></i></a>
    <!-- Insurance Partner -->
    <!-- <div class="insurance-Partner">
                <div class="title">
                    <h3>State Of The Art Equipment</h3>
                </div>
                <div class="title-bar"></div>
                <div class="owl-carousel owl-theme" style="margin-top: 10px">
                    <div class="item">
                        <img class="img-responsive" src="img/Logo.png">
                    </div>
                    <div class="item">
                        <img class="img-responsive" src="img/Logo.png">
                    </div>
                    <div class="item">
                        <img class="img-responsive" src="img/Logo.png">
                    </div>
                    <div class="item">
                        <img class="img-responsive" src="img/Logo.png">
                    </div>
                    <div class="item">
                        <img class="img-responsive" src="img/Logo.png">
                    </div>
                    <div class="item">
                        <img class="img-responsive" src="img/Logo.png">
                    </div>
                    <div class="item">
                        <img class="img-responsive" src="img/Logo.png">
                    </div>
                </div>
            </div>
             -->
    <!-- Footer -->
    </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
        </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="	sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
        </script>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\hospital-Project\resources\views/pages/home.blade.php ENDPATH**/ ?>