
<?php $__env->startSection('admin_content'); ?>


<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Update Department
            </header>
            <?php
            $message = Session::get('message');
            if($message){
                echo '<span class = "text-alert">',$message.'</span>';
                Session::put('message',null);
            }
            ?>
            <div class="panel-body">
                <?php $__currentLoopData = $edit_department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/update-department/'.$edit_value->department_id)); ?>" 
                        method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="exampleInputEmail1">Department Name</label>
                        <input type="text" value="<?php echo e($edit_value->department_name); ?>" name="department_name" 
                        class="form-control" id="exampleInputEmail1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Introduction</label>
                        <textarea style="resize:none" rows="5" type="text" name="department_introduction" class="form-control" 
                        id="exampleInputPassword1" ><?php echo e($edit_value->department_introduction); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Base</label>
                        <select name="department_base" class="form-control input-sm m-bot15">
                            <?php $__currentLoopData = $department_base; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $base_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($base_value->base_id==$edit_value->base_id): ?>
                            <option selected value="<?php echo e($base_value->base_id); ?>"><?php echo e($base_value->base_name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($base_value->base_id); ?>"><?php echo e($base_value->base_name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" name="update_department" class="btn btn-info">Update</button>
                </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\hospital-Project\resources\views/admin/department/edit_department.blade.php ENDPATH**/ ?>